Tool to look up
word definitions
examples
random words etc from the Internet usind wordnik API
